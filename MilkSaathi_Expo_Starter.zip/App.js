import React, { useState, useEffect } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from 'firebase/auth';
import { getFirestore, collection, addDoc, query, where, onSnapshot } from 'firebase/firestore';
import firebaseConfig from './config/firebaseConfig';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export default function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [liters, setLiters] = useState('');
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u) loadCustomers(u.uid);
      else setCustomers([]);
    });
    return () => unsub();
  }, []);

  const register = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      Alert.alert('सफल', 'रजिस्ट्रेशन सफल।');
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  };

  const login = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  const addCustomer = async () => {
    if (!name || !liters) { Alert.alert('Error', 'नाम और लिटर भरें'); return; }
    try {
      await addDoc(collection(db, 'customers'), {
        ownerUid: user.uid,
        name,
        phone,
        liters: Number(liters),
        createdAt: new Date().toISOString()
      });
      setName(''); setPhone(''); setLiters('');
    } catch (e) {
      Alert.alert('Error', e.message);
    }
  };

  const loadCustomers = (uid) => {
    const q = query(collection(db, 'customers'), where('ownerUid', '==', uid));
    return onSnapshot(q, (snap) => {
      const arr = [];
      snap.forEach(doc => arr.push({ id: doc.id, ...doc.data() }));
      setCustomers(arr);
    });
  };

  if (!user) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.header}>MilkSaathi - लॉगिन / रजिस्टर</Text>
        <TextInput placeholder='Email' value={email} onChangeText={setEmail} style={styles.input} />
        <TextInput placeholder='Password' value={password} onChangeText={setPassword} secureTextEntry style={styles.input} />
        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
          <TouchableOpacity style={styles.button} onPress={login}><Text style={styles.buttonText}>Login</Text></TouchableOpacity>
          <TouchableOpacity style={[styles.button, {backgroundColor:'#555'}]} onPress={register}><Text style={styles.buttonText}>Register</Text></TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>दूध डेयरी - {user.email}</Text>
      <TouchableOpacity style={{alignSelf:'flex-end', marginBottom:10}} onPress={logout}><Text>Logout</Text></TouchableOpacity>

      <TextInput placeholder='ग्राहक का नाम' value={name} onChangeText={setName} style={styles.input} />
      <TextInput placeholder='फ़ोन' value={phone} onChangeText={setPhone} style={styles.input} keyboardType='phone-pad' />
      <TextInput placeholder='दूध (लीटर)' value={liters} onChangeText={setLiters} style={styles.input} keyboardType='numeric' />
      <TouchableOpacity style={styles.button} onPress={addCustomer}><Text style={styles.buttonText}>ग्राहक जोड़ें</Text></TouchableOpacity>

      <Text style={{marginTop:20, fontSize:18, fontWeight:'600'}}>ग्राहक सूची</Text>
      <FlatList data={customers} keyExtractor={item=>item.id} renderItem={({item})=>(
        <View style={styles.listItem}>
          <Text style={{fontWeight:'600'}}>{item.name}</Text>
          <Text>{item.liters} लीटर</Text>
        </View>
      )} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:16, backgroundColor:'#f7f7f7' },
  header: { fontSize:20, fontWeight:'700', textAlign:'center', marginBottom:12 },
  input: { backgroundColor:'#fff', padding:10, borderRadius:8, marginVertical:6, borderWidth:1, borderColor:'#ddd' },
  button: { backgroundColor:'#2b8a3e', padding:12, borderRadius:8, marginTop:6 },
  buttonText: { color:'#fff', textAlign:'center', fontWeight:'600' },
  listItem: { backgroundColor:'#fff', padding:12, borderRadius:8, marginVertical:6, flexDirection:'row', justifyContent:'space-between', borderWidth:1, borderColor:'#eee' }
});
