MilkSaathi - Expo React Native Starter (Firebase integrated)
============================================================

यह प्रोजेक्ट एक बेसिक दूध/डेयरी मैनेजमेंट ऐप का Expo-React Native स्टार्टप्रोजेक्ट है।
इसमें Firebase Authentication (Email) और Firestore का उपयोग करके ग्राहक जोड़ने/देखने की क्षमता दी गई है।

**फीचर्स (MVP)**:
- Email/Password लॉगिन और रजिस्टर
- ग्राहक जोड़ना (नाम, फोन, लिटर)
- ग्राहक सूची Firestore में स्टोर
- ऑफ़लाइन नहीं (सरल MVP)

**जरूरी कदम (Firebase सेटअप)**:
1. firebase.google.com पर जाएँ और नया प्रोजेक्ट बनायें (MilkSaathi).
2. Project settings -> Web app जोड़ें और config (apiKey, authDomain, projectId, ...) कॉपी करें।
3. Authentication -> Sign-in method -> Email/Password ON करें।
4. Firestore -> Create database -> test mode (या RULES सेट कर लें)।

**config.js में Firebase कॉन्फ़िग भरें**:
./config/firebaseConfig.js फाइल में अपनी Firebase वेब-कॉन्फ़िग डालें।

**लाइब्रेरी इंस्टॉल और रन**:
- मशीन पर Node.js और Expo CLI होना चाहिए।
- टर्मिनल में:
    npm install
    npx expo start
    npx expo run:android   (या Expo Go से QR स्कैन कर के टेस्ट करें)

**APK बनाने के लिए (सरल तरीका)**:
- Expo Application Services (EAS) का उपयोग करें:
    npm install -g eas-cli
    eas login
    eas build -p android --profile preview
  या legacy:
    expo build:android (यदि पुराना CLI सपोर्ट हो)
- Firebase config और Google Play publishing के लिए keystore की ज़रूरत होगी।

**नोट**:
- मैं यहाँ APK बिल्ड नहीं कर पाया, लेकिन यह पूरा प्रोजेक्ट और बिल्ड निर्देश आपके पास हैं — आप इन्हें किसी लैपटॉप पर चलाकर APK बना सकते हैं या मैं आपकी तरफ़ से क्लाउड बिल्ड करने में मदद कर सकता हूँ (यदि आप लॉगिन शेयर कर दें तो)। सुरक्षा कारणों से कभी क्रेडेंशियल्स सीधे शेयर मत कीजिए।

**आगे क्या कर सकता हूँ (मैं कर दूँगा यदि कहें)**:
- OTP (फोन) लॉगिन + Firebase Phone Auth जोड़ दूँगा (थोड़ा अतिरिक्त सेटअप मांगता है)। 
- PDF बिल/इनवॉइस जनरेशन और शेयर फीचर जोड़ दूँगा।
- UPI पेमेंट intent इंटीग्रेट कर दूँगा।
- APK बना कर दे दूँगा (यदि आप मुझे बिल्ड-एनवायरनमेंट क्रेडेंशियल्स सुरक्षित रूप से दें या खुद EAS चलाना चाहें तो मैं गाइड कर दूँगा)।

--------------------------------------------
